export const sliderItems =[

    {
        id: 1,
        img: "https://i.imgur.com/SzEvjML.png",
        title: "BLACK FRIDAY SALE",
        desc: "DON'T COMPROMISE ON QUALITY! GET YOUR DEALS NOW.",
        bg: "f5fafd"

    },
    {
        id: 2,
        img: "https://i.imgur.com/SxuZXus.png",
        title: "Got A Cold?",
        desc: "RELIEF IS NEAR",
        bg: "f5fafd"


    },
    {
        id: 3,
        img: "https://i.imgur.com/nGvADAu.png",
        title: "Buy 1 Get 1 50% OFF",
        desc: "BUY ONE TUB OF OUR PREMIUM PROTEIN AND GET YOUR SECOND PURCHASE HALF OFF.",
        bg: "f5fafd"
        
    },
];

    export const categories = [
        {
          id: 1,
          img: "https://i.imgur.com/WIk40Bw.png",
          title: "SNACKS",
        },
        {
          id: 2,
          img: "https://i.imgur.com/IaovGQk.png",
          title: "FRUITS & VEGETABLES",
        },
        {
          id: 3,
          img: "https://i.imgur.com/vqcyk4x.png",
          title: "SOFT DRINKS",
        },
      ];
    
      export const popularProducts = [
        {
          id:1,
          img:"https://i.imgur.com/WCUCHOt.png",
        },
        {
          id:2,
          img:"https://i.imgur.com/8eKQmFA.png",
        },
        {
          id:3,
          img:"https://i.imgur.com/8OoSwwd.png",
        },
        {
          id:4,
          img:"https://i.imgur.com/HaPmybb.png",
        },
      ]
      

















